import React, { useState } from 'react'



export default function Header2() {


    return (
    <div>
<p>hello</p>
    </div>
  )
}


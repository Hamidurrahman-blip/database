import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import cartpage from '../pages/Cartpage'

export default function Header() {
 const Catgeoryurl="https://fakestoreapi.com/products/categories/"
 const [catgeory,setallcatgeory]=useState([])
 async function getallcatgeory(){
    const response=await fetch(Catgeoryurl)
    const data=await response.json()
    setallcatgeory(data)
 }
 useEffect(()=>{
    getallcatgeory()
 },[])
 
    return (
    <header className='header h-14 flex justify-between items-center
     text-white text-center px-12' >
<Link to="/"><img src='shopping.jpg' alt='image'  className=" ml-4 headimg "/></Link>
<div className='flex gap-8 '>
    {catgeory.map((item)=>{
return(
    <Link to={`catgeorypage/${item}`} key={item} className='capitalize
    text-black border-b-8'>
        {item}
    
    
    </Link>
)

    })} 
<Link to="/cartpage" className='capitalize
    text-black border-b-8'>cart</Link>
</div>

    </header>
  )
}

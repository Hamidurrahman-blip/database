import React from 'react'
import { Link } from 'react-router-dom'

export default function Cartcad({product}) {
  return (
    <Link to={`/product/${product.id}`} className='singlecart shadow-lg mt-10'>
 <img  className="images w-1/2 " src={product.image} />
            <h3>{product.title}</h3>
            <div className='productdec'>
                <p className='text-xl text-teal-700 mt-3'>
                  ${product.price}</p>

                <p className="bg-teal-500 mt-3 px-4 py-1 text-sm rounded-full">{product.rating.rate}</p>
    </div>
    </Link>
  )
}
